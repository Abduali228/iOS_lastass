
import Foundation

struct Constants {
    static let host = "https://api.openweathermap.org/data/2.5/onecall?lat=51.1801&lon=71.446&exclude=minutely,alerts&appid=0e9477e67e53c8c91844f7d87860ae02&units=metric"
    static let city = "Astana"
    static let apiKey = ""
}
